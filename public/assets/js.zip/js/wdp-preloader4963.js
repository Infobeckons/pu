/*
Version : 1.1
*/

jQuery(window).load(function($){

    "use strict";

    /* Hide preloader after all contents are loaded */
    jQuery('.wdp_preloader').addClass('animated fadeOutDown');
});